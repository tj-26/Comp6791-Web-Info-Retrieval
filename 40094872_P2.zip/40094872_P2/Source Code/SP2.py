import json
from nltk import PorterStemmer
import SP1
import SP3


def sample_query(INPUT_STRUCTURE, file_name):  # method to run the sample queries
    # print(token_dict)
    query_dict = {}
    for inp in INPUT_STRUCTURE:

        if inp in SP1.token_dict:  # check if the term is present in the indexer
            query_dict[inp] = SP1.token_dict[inp]
        else:
            query_dict[inp] = ["NA"]  # if the term is not present result NA

    json.dump(query_dict, open(file_name, "w", encoding="utf−8"),
              indent=3)  # create the json file for the sample  queries


def sample_query_indexer(INPUT_STRUCTURE, file_name):  # method to run the sample queries
    query_dict = {}
    ps = PorterStemmer()  # Porter Stemmer to stem the challenge queries
    INPUT_STRUCTURE = [i for i in INPUT_STRUCTURE if not (i.isdigit())]  # checking if the term is digit
    INPUT_STRUCTURE = [i.lower() for i in INPUT_STRUCTURE]  # doing the case folding of the term
    INPUT_STRUCTURE = [i for i in INPUT_STRUCTURE if i not in SP3.stopwords_30]  # removing the stop words 30
    INPUT_STRUCTURE = [i for i in INPUT_STRUCTURE if i not in SP3.stopwords_150]  # removing the stop words 150
    INPUT_STRUCTURE = [ps.stem(i) for i in INPUT_STRUCTURE]  # stemming all the challenge queries

    for inp in INPUT_STRUCTURE:

        if inp in SP3.stemmer_dict:  # check if the term is present in the indexer
            query_dict[inp] = SP3.stemmer_dict[inp]
        else:
            query_dict[inp] = ["NA"]  # if the term is not present result NA

    json.dump(query_dict, open(file_name, "w", encoding="utf−8"),
              indent=3)  # create the json file for the sample  queries
