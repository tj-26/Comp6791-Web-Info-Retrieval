import os
import nltk
from bs4 import BeautifulSoup
from regex import regex
import SP1


def stemmer():  # method to apply the Porter Stemmer to stem the terms
    reuters_doc = []
    document = []
    doc_text = []
    stemmer_dict = {}
    content_dicts = []
    token_tuples = []
    for file in os.listdir("./reuters21578"):
        if file.endswith('.sgm'):  # checking for files with .sgm extension
            with open(os.path.join("./reuters21578", file),  # open the files and ignore errors to avoid utf-8 error
                      errors='ignore') as f:
                reuters_file_content = f.read()  # putting all the read text in reuters_file_content
                reuters_doc.append(reuters_file_content)  # storing the content into a list

    for inp in reuters_doc:
        # using the regex to append the empty document list
        document.append(regex.split('<!DOCTYPE lewis SYSTEM "lewis.dtd">', inp)[1])
        # print(document[0])

    for doc in document:
        inp = doc
        flag = True  # using a flag to check for document end

        while flag:  # loop while the flag is true

            if '<REUTERS' in inp:
                start_tag = inp.index('<REUTERS')  # tags to define the start index of a reuter
                end_tag = inp.index('</REUTERS>')  # tags to define the end index of a reuter
                doc_text.append(inp[start_tag: end_tag + 10])  # populate document_text with reuters content
                inp = inp[end_tag + 10:]  # update the index value
            else:
                flag = False

    for inp in doc_text:
        bs = BeautifulSoup(inp, 'html.parser')  # using beautiful soup to parse html/xml
        text = bs.find('text')
        # print(text.get('type'))

        if text.get('type') == 'UNPROC' or text.get('type') == 'BRIEF':  # check for text type unproc and brief
            error = "empty blocks"
        else:
            reuters = bs.find('reuters')  # find reuters
            iD = int(reuters.get('newid'))  # find the docID
            title = bs.find('title').string  # find the title
            dateline = bs.find('dateline').string  # find the dateline
            body = bs.find('body').string  # find the body
            finalText = title + dateline + body  # concatenate the final string
            for t in finalText:
                if t in SP1.special_symbols:
                    finalText = finalText.replace(t, " ")

            content_dicts.append({"ID": iD, "TEXT": finalText})  # dictionary structure of output
            # print(content_dict)

    for inp in content_dicts:
        text = nltk.word_tokenize(inp['TEXT'])  # using word tokenizer to generate tokens
        text = [i.lower() for i in text]

        with open("stopwords_150.txt") as file:  # read first 30 stop words
            stopwords_150 = file.read().splitlines()  # generating a list of stop words
        with open("stopwords_30.txt") as file:  # read first 30 stop words
            stopwords_30 = file.read().splitlines()  # generating a list of stop words
        for t in text:
            if not (t.isdigit()) and t not in stopwords_30 and t not in stopwords_150:
                token_tuples.append([inp['ID'], nltk.PorterStemmer().stem(t)])  # token tuple structure of output
                # sorting the tuples
    single_token_tuple = list(set(tuple(i) for i in token_tuples))  # separating the unique tuple
    single_token_tuple.sort(key=lambda single_token_tuple: single_token_tuple[1])  # sorting the tuple

    for tupl in single_token_tuple:
        if tupl[1] not in stemmer_dict:  # if the key is not present
            stemmer_dict[tupl[1]] = [tupl[0]]  # create the term and doc id

        else:
            temp = stemmer_dict.get(tupl[1])  # append the doc id to the existing
            temp.append(tupl[0])
            stemmer_dict[tupl[1]] = temp

    return stemmer_dict
