import time

import SP1
import SP2
import SP3
start = time.time()
SP1.reader("./reuters21578") # reading the reuters
SP1.document_segmenter(SP1.reuters_doc) #segment the document
SP1.extractor(SP1.doc_text) # extract to the doccument
SP1.tokenizer(SP1.content_dict) # tokenise the text
SP1.naive_index(SP1.single_token_tuple) # build the naive indexer
print("Total time taken by naive indexer to build is--- %s seconds ---" % (time.time() - start))

SP2.sample_query(["unsolicited", "thermoplastic", "zones"], "sampleQueries.json") # sample queries
SP2.sample_query(["pineapple", "Phillippines", "Brierley", "Chrysler"], "challengeQueries.json") # challenge queries

SP3.filter_num_tokens() # remove no. tokens
SP3.lowercase_tokens() # lower case token
SP3.stopwords_removal_30('stopwords_30.txt') # remove 30 stop words
SP3.stopwords_removal_150('stopwords_150.txt') # remove 150 stop words
SP3.stemmer() # apply stemmer
SP3.table_creation() # table creation
SP2.sample_query_indexer(["unsolicited", "thermoplastic", "zones"], "sampleQueriesFinalIndexer.json") # sample queries
SP2.sample_query_indexer(["pineapple", "Phillippines", "Brierley", "Chrysler"], "challengeQueriesFinalIndexer.json") # challenge queries