import json  # import json for the file output
import os  # import os to read file
import regex # import regex to match the content
import nltk # import nltk library
import ssl # import ssl to avoid error

try:
    _create_unverified_https_context = ssl._create_unverified_context # to avoid ssl error try block
except AttributeError:  # generate exception
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context # handling exception

nltk.download('punkt') # download nltk punkt
from bs4 import BeautifulSoup # import BeautifulSoup
from nltk import word_tokenize, PorterStemmer

reuters_doc = [] # list to store reuters document
document = [] # list to store 22 sgm files
doc_text = [] # list to store text
content_dict = [] # list to store content of document
token_tuple = [] # list to store tuple
single_token_tuple = [] # list to store unique tuple
punct_token_tuple = [] # list to store punctutation tuple
token_dict = {} # list to store dictionary
special_symbols = '''!()[]{};:'"\,<>./``''?+-#$%^&*_~''' # punctutation symbols

def reader(path):   # code to read files
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^
    for file in os.listdir(path):
        if file.endswith('.sgm'):  # checking for files with .sgm extension
            with open(os.path.join(path, file),  # open the files and ignore errors to avoid utf-8 error
                      errors='ignore') as f:
                reuters_file_content = f.read()  # putting all the read text in reuters_file_content
                reuters_doc.append(reuters_file_content) # storing the content into a list
    # print(reuters_doc[0])


def document_segmenter(INPUT_STRUCTURE): # segment the document from the first line
    for inp in INPUT_STRUCTURE:
        # using the regex to append the empty document list
        document.append(regex.split('<!DOCTYPE lewis SYSTEM "lewis.dtd">', inp)[1])
    # print(document[0])

    for doc in document:
        inp = doc
        flag = True  # using a flag to check for document end

        while flag:  # loop while the flag is true

            if '<REUTERS' in inp:
                start_tag = inp.index('<REUTERS')  # tags to define the start index of a reuter
                end_tag = inp.index('</REUTERS>')  # tags to define the end index of a reuter
                doc_text.append(inp[start_tag: end_tag + 10])  # populate document_text with reuters content
                inp = inp[end_tag + 10:]  # update the index value
            else:
                flag = False

    # print(doc_text[0])


def extractor(INPUT_STRUCTURE):
    for inp in INPUT_STRUCTURE:
        bs = BeautifulSoup(inp, 'html.parser')  # using beautiful soup to parse html/xml
        text = bs.find('text')
        # print(text.get('type'))

        if text.get('type') == 'UNPROC' or text.get('type') == 'BRIEF':  # check for text type unproc and brief
            error = "empty blocks"
        else:
            reuters = bs.find('reuters')  # find reuters
            iD = int(reuters.get('newid'))  # find the docID
            title = bs.find('title').string  # find the title
            dateline = bs.find('dateline').string  # find the dateline
            body = bs.find('body').string  # find the body
            finalText = title + dateline + body  # concatenate the final string
            for t in finalText:
                if t in special_symbols:
                    finalText = finalText.replace(t, " ")
            content_dict.append({"ID": iD, "TEXT": finalText})  # dictionary structure of output
            # print(content_dict)


def tokenizer(INPUT_STRUCTURE):
    for inp in INPUT_STRUCTURE:
        text = word_tokenize(inp['TEXT'])  # using word tokenizer to generate tokens

        for t in text:
            token_tuple.append([inp['ID'], t])  # token tuple structure of output

    token_tuple.sort(key=lambda token_tuple: token_tuple[1]) # sorting the tuples
    global single_token_tuple
    single_token_tuple = list(set(tuple(i) for i in token_tuple)) # separating the unique tuple
    single_token_tuple.sort(key=lambda single_token_tuple: single_token_tuple[1]) # sorting the tuple


def naive_index(INPUT_STRUCTURE):  # building the naive indexer
    # using a special symbol list to remove unwanted token
    for tupl in INPUT_STRUCTURE:
        if tupl[1] not in token_dict: # if the key is not present
            token_dict[tupl[1]] = [tupl[0]] # create the term and doc id

        else:
            temp = token_dict.get(tupl[1]) # append the doc id to the existing
            temp.append(tupl[0])
            token_dict[tupl[1]] = temp

    json.dump(token_dict, open("naiveIndexDictionary.json", "w", encoding="utf−8"), indent=3) # printing the indexer into the json file






