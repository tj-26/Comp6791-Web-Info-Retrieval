import os
import nltk
from bs4 import BeautifulSoup
from regex import regex
import SP1


def case_folding():  # method to apply the Porter Stemmer to stem the terms
    reuters_doc = []
    document = []
    doc_text = []
    casefold_dict = {}
    content_dicts = []
    token_tuples = []

    for file in os.listdir("./reuters21578"):
        if file.endswith('.sgm'):  # checking for files with .sgm extension
            with open(os.path.join("./reuters21578", file),  # open the files and ignore errors to avoid utf-8 error
                      errors='ignore') as f:
                reuters_file_content = f.read()  # putting all the read text in reuters_file_content
                reuters_doc.append(reuters_file_content)  # storing the content into a list

    for inp in reuters_doc:
        # using the regex to append the empty document list
        document.append(regex.split('<!DOCTYPE lewis SYSTEM "lewis.dtd">', inp)[1])
        # print(document[0])

    for doc in document:
        inp = doc
        flag = True  # using a flag to check for document end
        while flag:  # loop while the flag is true
            if '<REUTERS' in inp:
                start_tag = inp.index('<REUTERS')  # tags to define the start index of a reuter
                end_tag = inp.index('</REUTERS>')  # tags to define the end index of a reuter
                doc_text.append(inp[start_tag: end_tag + 10])  # populate document_text with reuters content
                inp = inp[end_tag + 10:]  # update the index value
            else:
                flag = False

    for inp in doc_text:
        bs = BeautifulSoup(inp, 'html.parser')  # using beautiful soup to parse html/xml
        text = bs.find('text')
        if text.get('type') == 'UNPROC' or text.get('type') == 'BRIEF':  # check for text type unproc and brief
            error = "empty blocks"
        else:
            reuters = bs.find('reuters')  # find reuters
            iD = int(reuters.get('newid'))  # find the docID
            title = bs.find('title').string  # find the title
            dateline = bs.find('dateline').string  # find the dateline
            body = bs.find('body').string  # find the body
            finalText = title + dateline + body  # concatenate the final string
            for t in finalText:
                if t in SP1.special_symbols:
                    finalText = finalText.replace(t, " ")

            content_dicts.append({"ID": iD, "TEXT": finalText})  # dictionary structure of output

    for inp in content_dicts:
        text = nltk.word_tokenize(inp['TEXT'])  # using word tokenizer to generate tokens
        text = [i.lower() for i in text]
        for t in text:
           if not(t.isdigit()):
               token_tuples.append([inp['ID'], t])  # token tuple structure of output

    single_token_tuple = list(set(tuple(i) for i in token_tuples))  # separating the unique tuple
    single_token_tuple.sort(key=lambda single_token_tuple: single_token_tuple[1])  # sorting the tuple

    for tupl in single_token_tuple:
        if tupl[1] not in casefold_dict:  # if the key is not present
            casefold_dict[tupl[1]] = [tupl[0]]  # create the term and doc id

        else:
            temp = casefold_dict.get(tupl[1])  # append the doc id to the existing
            temp.append(tupl[0])
            casefold_dict[tupl[1]] = temp

    return casefold_dict