from texttable import Texttable

import SP1
import CaseFolding
import PorterStemmer

non_dict = {}   # dictionary to store the index after removing no.
lower_dict = {}  # dictionary to store the index after case folding
stop_dict_30 = {}  # dictionary to store the index after removing 30 stop words
stop_dict_150 = {}  # dictionary to store the index after removing 150 stop words
stemmer_dict = {}  # dictionary to store the index after applying Porter Stemmer
table_row_data = []  # list to build the table
stopwords_30 = []  # list for first 30 stopwords
stopwords_150 = []  # list for first 150 stopwords


def filter_num_tokens(): # method to remove the no
    for token, val in SP1.token_dict.items():
        if token.isdigit(): # if the token is digit ignore it
            error = "error"

        else:
            non_dict[token] = val # else build new dictionary


def lowercase_tokens(): # method to do case folding
    global lower_dict
    lower_dict = CaseFolding.case_folding()


def stopwords_removal_30(file_name):  # method to remove the 30 stop words
    with open(file_name) as file:  # read first 30 stop words
        stopwords_30 = file.read().splitlines()  # generating a list of stop words

    for token in lower_dict:
        if token in stopwords_30:
            error = "error"

        else:
            stop_dict_30[token] = lower_dict.get(token) # appending the token if it is not a stop word


def stopwords_removal_150(file_name):  # method to remove 150 stop words
    with open(file_name) as file:  # read first 30 stop words
        stopwords_150 = file.read().splitlines()  # generating a list of stop words

    for token in lower_dict:
        if token in stopwords_150:
            error = "error"

        else:
            stop_dict_150[token] = lower_dict.get(token) # appending the token if it is not a stop word


def stemmer():  # method to apply the Porter Stemmer to stem the terms
    global stemmer_dict
    stemmer_dict = PorterStemmer.stemmer()


def non_positional_index(INPUT_STRUCTURE): # method to calculate the non positional postings of the list
    count = 0

    for token in INPUT_STRUCTURE:
        if isinstance(INPUT_STRUCTURE[token], list):  # count the no. of postings list
            count += len(INPUT_STRUCTURE[token])

    return count  # return the count of the postings list of the passed dictionary


def table_creation():  # creating the table
    tokens_count = 0
    non_positional_count = 0
    table = Texttable() # using Texttable library to generate the table
    row_data = ['', 'Distinct terms', '', '', '', 'Non positional postings', ''] # headers of the table
    table_row_data.append(row_data)
    row_data = ['', 'number', '\u0394%', 'T%', 'number', '\u0394%', 'T%'] # sub headings
    table_row_data.append(row_data)
    row_data = ['unfiltered', len(SP1.token_dict), '', '', non_positional_index(SP1.token_dict), '', '']  # calculating unfiltered
    table_row_data.append(row_data)
    tokens = 100 * (len(SP1.token_dict) - len(non_dict)) / len(SP1.token_dict)
    tokens_count += tokens
    non_positional = 100 * (non_positional_index(SP1.token_dict) - non_positional_index(non_dict)) / non_positional_index(SP1.token_dict)
    non_positional_count += non_positional
    row_data = ['no numbers', len(non_dict), -tokens, -tokens_count, non_positional_index(non_dict), -non_positional,
           -non_positional_count]  # calculating no numners
    table_row_data.append(row_data)
    tokens = 100 * (len(non_dict) - len(lower_dict)) / len(non_dict)
    tokens_count += tokens
    non_positional = 100 * (non_positional_index(non_dict) - non_positional_index(lower_dict)) / non_positional_index(
        non_dict)
    non_positional_count += non_positional
    row_data = ['case folding', len(lower_dict), -tokens, -tokens_count, non_positional_index(lower_dict),
                -non_positional,
                -non_positional_count]  # calculating the case folding
    table_row_data.append(row_data)
    tokens = 100 * (len(lower_dict) - len(stop_dict_30)) / len(lower_dict)
    tokens_count += tokens
    non_positional = 100 * (non_positional_index(lower_dict) - non_positional_index(stop_dict_30)) / non_positional_index(lower_dict)
    non_positional_count += non_positional
    row_data = ['30 stop words', len(stop_dict_30), -tokens, -tokens_count, non_positional_index(stop_dict_30),
                -non_positional,
                -non_positional_count]  # calculating 30 stop words removal
    table_row_data.append(row_data)
    tokens = 100 * (len(stop_dict_30) - len(stop_dict_150)) / len(stop_dict_30)
    tokens_count += tokens
    non_positional = 100 * (
                non_positional_index(stop_dict_30) - non_positional_index(stop_dict_150)) / non_positional_index(stop_dict_30)
    non_positional_count += non_positional
    row_data = ['150 stop words', len(stop_dict_150), -tokens, -tokens_count, non_positional_index(stop_dict_150),
                -non_positional,
                -non_positional_count]  # calculating 150 stop words removal
    table_row_data.append(row_data)
    tokens = 100 * (len(stop_dict_150) - len(stemmer_dict)) / len(stop_dict_150)
    tokens_count += tokens
    non_positional = 100 * (
                non_positional_index(stop_dict_150) - non_positional_index(stemmer_dict)) / non_positional_index(
        stop_dict_150)
    non_positional_count += non_positional
    row_data = ['Stemmer', len(stemmer_dict), -tokens, -tokens_count, non_positional_index(stemmer_dict),
                -non_positional,
                -non_positional_count]  # calculating stemmer
    table_row_data.append(row_data)

    for rows in table_row_data:
        table.add_row(rows)  # adding all the rows

    print(table.draw())  # draw the table









