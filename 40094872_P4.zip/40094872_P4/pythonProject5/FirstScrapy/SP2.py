import math
import FirstScrapy.SP1
avg_length = 0

def bm25(query, k, b):  # define the method for bm25

    bm25_dict = {}  # dictionary to store page ranking for each document
    t_length = 0

    for doc in FirstScrapy.SP1.doc_size:
        t_length += FirstScrapy.SP1.doc_size[doc]   # calculate the total length of reuters

    avg_length = t_length/ len(FirstScrapy.SP1.doc_size)    # average length of a document in reuters21578

    if query in FirstScrapy.SP1.merge_dict:
        posting_list = FirstScrapy.SP1.merge_dict[query]    # get the posting list from merged index
        docfreq = FirstScrapy.SP1.doc_freq[query]
    else:
        posting_list = {}
        docfreq = 0


    for doc in posting_list:

        term_freq = posting_list[doc]   # get the term frequency
        doc_num = len(FirstScrapy.SP1.doc_size)     # get the total number of documents
        c_doc_length = FirstScrapy.SP1.doc_size[doc]    # get the size of current document

        # bm25 formula
        log10 = math.log10(doc_num/ docfreq)
        u = (k + 1) * term_freq
        l = k * ((1 - b) + b * (c_doc_length / avg_length)) + term_freq
        rsv = log10 * u / l

        bm25_dict[doc] = rsv  # update the dictionary with document and corresponding rsv

    # print(dict(sorted(bm25_dict.items(),key=lambda d: d[1], reverse=True)))
    return dict(sorted(bm25_dict.items(),key=lambda d: d[1], reverse=True))

def bm25_s(query):  # bm25 for several queries

    bm25_s_dict = {}
    bm25_s_f_dict = {}

    for t in query:
        if t in FirstScrapy.SP1.special_symbols:
            query = query.replace(t, " ") # remove punctuation

    # print(query)

    for quer in query:
        bm25_s_dict[quer] = bm25(quer, 3, 0.4)  # calling bm25 for individual tokens

    for query_bm in bm25_s_dict:
        post_list = bm25_s_dict[query_bm]

        for post in post_list: # add doc id rsv values
            if post in bm25_s_f_dict:
                bm25_s_f_dict[post] += post_list[post] # add the postings list value
            else:
                bm25_s_f_dict[post] = post_list[post] # create key with doc id

    return dict(sorted(bm25_s_f_dict.items(), key=lambda d: d[1], reverse=True))


def SPIMI_AND(query): # spimi block for AND queries

    spimi_dict = {} # temp dict
    spimi_and = {} # dict to store and doc id
    and_list = [] # list to store and doc ids

    query_list = query.split(' ') # split the queries
    # print(query_list)

    for quer in query_list:
        spimi_dict[quer] = FirstScrapy.SP1.merge_dict[quer]

    for query in spimi_dict:  # iterate dictionary
        tmp = spimi_dict[query]
        for post in tmp:
            if post in spimi_and:
                spimi_and[post] += 1 # update value
            else:
                spimi_and[post] = 1

    for p in spimi_and:
        if spimi_and[p] == len(query_list): # if the query list lenght is equal to doc id sum
            and_list.append(p)

    return and_list

def SPIMI_OR(query): # SPIMI to test OR queries

    spimi_dict = {} # to store temp dic
    spimi_or = {} # to store or doc id

    for quer in query:
        if quer in FirstScrapy.SP1.merge_dict:
            spimi_dict[quer] = FirstScrapy.SP1.merge_dict[quer]

    for query in spimi_dict:
        tmp = spimi_dict[query]
        for post in tmp:

            if post in spimi_or:
                spimi_or[post] += 1 # update the value by 1
            else:
                spimi_or[post] = 1 # create new key with doc id

    return dict(sorted(spimi_or.items(), key=lambda d: d[1], reverse=True)) # return the sorted doc id in descending order by rsv value













