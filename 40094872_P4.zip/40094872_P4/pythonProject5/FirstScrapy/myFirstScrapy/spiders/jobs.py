import json
import scrapy


class JobsSpider(scrapy.Spider):
    name = 'jobs'
    allowed_domains = ['www.concordia.ca']
    start_urls = ['http://www.concordia.ca/']

    def __init__(self, foo=None, *args, **kwargs):

        super(JobsSpider, self).__init__(*args, **kwargs)
        self.i = 100
        self.map = {}
    rules = [scrapy.spiders.Rule(scrapy.linkextractors.LinkExtractor(), callback='parse', follow=True)]

    def parse(self, response):

        self.map[self.i] = response.url
        f = open(str(self.i)+".html", "w")
        f.write(str(response.body))
        f.close()
        self.i = self.i + 1
        for next_page in response.css('a::attr(href)'):
            yield response.follow(next_page, self.parse)

        json.dump(self.map, open("map.json", "w", encoding="utf−8"))