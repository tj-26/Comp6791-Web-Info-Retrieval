import json
import time
import FirstScrapy.SP1
import FirstScrapy.SP2
import FirstScrapy.SP3

start = time.time()
FirstScrapy.SP1.reader("./") # reading the html files
FirstScrapy.SP1.extractor(FirstScrapy.SP1.reuters_doc)
FirstScrapy.SP1.tokenizer(FirstScrapy.SP1.content_dict) # tokenise the text
FirstScrapy.SP1.block_generate(FirstScrapy.SP1.token_tuple) # generate the blocks of size 500

FirstScrapy.SP1.merge_block(FirstScrapy.SP1.block_list) # generate the merged index
FirstScrapy.SP1.document_frequency(FirstScrapy.SP1.merge_dict)

FirstScrapy.SP3.load_file()



# #-------------------Test-query1 bm25-----------------------
bm25_sq = "which researchers  Concordia worked on COVID 19- research"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
print(spimi_qr)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_bm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query1 tf-idf-----------------------
tf_idf_sq = "which researchers  Concordia worked on COVID 19- research"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_tf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query1 different measure-----------------------
spimi_sq = "which researchers Concordia worked on COVID 19- research"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_diffmeasure.json", "w", encoding="utf−8"),indent=3)


# #-------------------Test-query1 variation bm25-----------------------
bm25_sq = "researchers Concordia COVID 19"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_variationbm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query1 variation tf-idf-----------------------
tf_idf_sq = "researchers Concordia COVID 19"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_variationtf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query1 variation different measure-----------------------
spimi_sq = "researchers Concordia COVID 19"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ1_variationdiffmeasure.json", "w", encoding="utf−8"),indent=3)



# #-------------------Test-query2 bm25-----------------------
bm25_sq = "which  at Concordia have research in environmental , sustainability, energy and water"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_bm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query2 tf-idf-----------------------
tf_idf_sq =  "which  at Concordia have research in environmental , sustainability, energy and water "
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_tf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query2 different measure-----------------------
spimi_sq =  "which  at Concordia have research in environmental , sustainability, energy and water"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_diffmeasure.json", "w", encoding="utf−8"),indent=3)


# #-------------------Test-query2 variation bm25-----------------------
bm25_sq = " Concordia research environmental  sustainability energy water"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_variationbm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query2  variation tf-idf-----------------------
tf_idf_sq =  " Concordia research environmental  sustainability energy water"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_variationtf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Test-query2 variation different measure-----------------------
spimi_sq =  " Concordia research environmental  sustainability energy water"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("TQ2_variationdiffmeasure.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query1 bm25-----------------------
bm25_sq = "water management sustainability Concordia"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ1_bm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query1 tf-idf-----------------------
tf_idf_sq = "water management sustainability Concordia"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ1_tf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query1 different measure-----------------------
spimi_sq = "water management sustainability Concordia"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ1_diffmeasure.json", "w", encoding="utf−8"),indent=3)


# #-------------------Challenge-query2 bm25-----------------------
bm25_sq = "Concordia COVID-19 faculty"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ2_bm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query2 tf-idf-----------------------
tf_idf_sq = "Concordia COVID-19 faculty"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ2_tf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query2 different measure-----------------------
spimi_sq = "Concordia COVID-19 faculty"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ2_diffmeasure.json", "w", encoding="utf−8"),indent=3)


# #-------------------Challenge-query3 bm25-----------------------
bm25_sq = "SARS-CoV Concordia faculty"
bm25_pq = FirstScrapy.SP3.pre_process_qt(bm25_sq)
spimi_qr = FirstScrapy.SP2.bm25_s(bm25_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ3_bm25.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query3 tf-idf-----------------------
tf_idf_sq = "SARS-CoV Concordia faculty"
tf_idf_pq = FirstScrapy.SP3.pre_process_qt(tf_idf_sq)
spimi_qr = FirstScrapy.SP3.tf_idf_s(tf_idf_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ3_tf-idf.json", "w", encoding="utf−8"),indent=3)

# #-------------------Challenge-query3 different measure-----------------------
spimi_sq = "SARS-CoV Concordia faculty"
spimi_pq = FirstScrapy.SP3.pre_process_qt(spimi_sq)
spimi_qr = FirstScrapy.SP2.SPIMI_OR(spimi_pq)
spimi_qr = FirstScrapy.SP3.load_url(spimi_qr)
json.dump(spimi_qr, open("CQ3_diffmeasure.json", "w", encoding="utf−8"),indent=3)

print("Total time taken by to build is--- %s seconds ---" % (time.time() - start))