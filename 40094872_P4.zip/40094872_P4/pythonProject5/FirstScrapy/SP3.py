import ast

import nltk
nltk.download('stopwords')
from nltk import word_tokenize
from nltk import PorterStemmer

import FirstScrapy.SP1
import math

stop_word_text = []
stemmed_text = []
url = {}

def tf_idf(query, k, b):  # define the method for bm25

    tf_dict = {}  # dictionary to store page ranking for each document
    t_length = 0

    for doc in FirstScrapy.SP1.doc_size:
        t_length += FirstScrapy.SP1.doc_size[doc]  # calculate the total length of reuters

    # avg_length = t_length / len(FirstScrapy.SP1.doc_size)  # average length of a document in reuters21578
    if query in FirstScrapy.SP1.merge_dict:
        posting_list = FirstScrapy.SP1.merge_dict[query]  # get the posting list from merged index
        docfreq = FirstScrapy.SP1.doc_freq[query]
    else:
        posting_list = {}
        docfreq = 0
    for doc in posting_list:
        term_freq = posting_list[doc]  # get the term frequency
        doc_num = len(FirstScrapy.SP1.doc_size)  # get the total number of documents
        # c_doc_length = FirstScrapy.SP1.doc_size[doc]  # get the size of current document

        # tf-idf formula
        tf = 1 + math.log10(term_freq)
        idf = math.log10(doc_num / docfreq)
        tf_idf = tf * idf

        tf_dict[doc] = tf_idf  # update the dictionary with document and corresponding rsv

    # print(dict(sorted(bm25_dict.items(),key=lambda d: d[1], reverse=True)))
    return dict(sorted(tf_dict.items(), key=lambda d: d[1], reverse=True))


def tf_idf_s(query):  # bm25 for several queries

    tf_s_dict = {}
    tf_s_f_dict = {}

    for t in query:
        if t in FirstScrapy.SP1.special_symbols:
            query = query.replace(t, " ")  # remove punctuation

    for quer in query:
        tf_s_dict[quer] = tf_idf(quer, 3, 0.4)  # calling bm25 for individual tokens

    for query_bm in tf_s_dict:
        post_list = tf_s_dict[query_bm]

        for post in post_list:  # add doc id rsv values
            if post in tf_s_f_dict:
                tf_s_f_dict[post] += post_list[post]  # add the postings list value
            else:
                tf_s_f_dict[post] = post_list[post]  # create key with doc id

    return dict(sorted(tf_s_f_dict.items(), key=lambda d: d[1], reverse=True))

def pre_process_qt(query):


    for q in query:
        if q in FirstScrapy.SP1.special_symbols:
            query = query.replace(q, " ")

    text = word_tokenize(query)  # using word tokenizer to generate tokens
    text = [i.lower() for i in text]
    stopword = list(nltk.corpus.stopwords.words('english'))  # generating a list of stop words in english language

    for t in text:
        if t in stopword:  # check if stop word is present in token
            error = "stop word found"
        else:
            stop_word_text.append(t)

    for swt in stop_word_text:
        stemmed_text.append(PorterStemmer().stem(swt))

    return stemmed_text


def load_file():
    with open('map.json', 'r') as f:
        global url
        url = ast.literal_eval(f.read())


def load_url(q_results):

    results = {}
    counter = 0
    for i in q_results:

        counter+=1
        tmp = url[i]
        results[tmp] = q_results[i]
        if counter == 15:
            break

    return results
