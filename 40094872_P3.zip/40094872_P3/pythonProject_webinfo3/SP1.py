import json  # import json for the file output
import math
import os  # import os to read file
import regex # import regex to match the content
import nltk # import nltk library
import ssl # import ssl to avoid error

try:
    _create_unverified_https_context = ssl._create_unverified_context # to avoid ssl error try block
except AttributeError:  # generate exception
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context # handling exception

nltk.download('punkt') # download nltk punkt
from bs4 import BeautifulSoup # import BeautifulSoup
from nltk import word_tokenize, PorterStemmer

reuters_doc = [] # list to store reuters document
document = [] # list to store 22 sgm files
doc_text = [] # list to store text
content_dict = [] # list to store content of document
token_tuple = [] # list to store tuple
single_token_tuple = [] # list to store unique tuple
punct_token_tuple = [] # list to store punctutation tuple
token_dict = {} # list to store dictionary
special_symbols = '''!()[]{};:'"\,<>./``''?+-#$%^&*_~''' # punctutation symbols
block_list = []
merge_dict = {}
doc_size = {}

def reader(path):   # code to read files
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^
    for file in os.listdir(path):
        if file.endswith('.sgm'):  # checking for files with .sgm extension
            with open(os.path.join(path, file),  # open the files and ignore errors to avoid utf-8 error
                      errors='ignore') as f:
                reuters_file_content = f.read()  # putting all the read text in reuters_file_content
                reuters_doc.append(reuters_file_content) # storing the content into a list
    # print(reuters_doc[0])


def document_segmenter(INPUT_STRUCTURE): # segment the document from the first line
    for inp in INPUT_STRUCTURE:
        # using the regex to append the empty document list
        document.append(regex.split('<!DOCTYPE lewis SYSTEM "lewis.dtd">', inp)[1])
    # print(document[0])

    for doc in document:
        inp = doc
        flag = True  # using a flag to check for document end

        while flag:  # loop while the flag is true

            if '<REUTERS' in inp:
                start_tag = inp.index('<REUTERS')  # tags to define the start index of a reuter
                end_tag = inp.index('</REUTERS>')  # tags to define the end index of a reuter
                doc_text.append(inp[start_tag: end_tag + 10])  # populate document_text with reuters content
                inp = inp[end_tag + 10:]  # update the index value
            else:
                flag = False

    # print(doc_text[0])


def extractor(INPUT_STRUCTURE):
    for inp in INPUT_STRUCTURE:
        bs = BeautifulSoup(inp, 'html.parser')  # using beautiful soup to parse html/xml
        text = bs.find('text')
        # print(text.get('type'))

        if text.get('type') == 'UNPROC' or text.get('type') == 'BRIEF':  # check for text type unproc and brief
            error = "empty blocks"
        else:
            reuters = bs.find('reuters')  # find reuters
            iD = int(reuters.get('newid'))  # find the docID
            title = bs.find('title').string  # find the title
            dateline = bs.find('dateline').string  # find the dateline
            body = bs.find('body').string  # find the body
            finalText = title + dateline + body  # concatenate the final string
            for t in finalText:
                if t in special_symbols:
                    finalText = finalText.replace(t, " ")
            content_dict.append({"ID": iD, "TEXT": finalText})  # dictionary structure of output
            # print(content_dict)


def tokenizer(INPUT_STRUCTURE):
    for inp in INPUT_STRUCTURE:
        text = word_tokenize(inp['TEXT'])  # using word tokenizer to generate tokens
        doc_size[inp['ID']] = len(text)
        for t in text:
            token_tuple.append([t, inp['ID']])  # token tuple structure of output

    token_tuple.sort(key=lambda token_tuple: token_tuple[1]) # sorting the tuples
    json.dump(token_tuple, open("token_tuples.json", "w", encoding="utf−8"))

def block_generate(INPUT_STRUCTURE):    # block to generate

    count = 0
    temp_list = {}  # take a temporary list

    for inp in INPUT_STRUCTURE: # iterate the token list
        count += 1

        if count != 50000 and inp != INPUT_STRUCTURE[-1]:# generate blocks of 10000 tokens
            if inp[0] in temp_list:
                doc_dict = temp_list.get(inp[0])    # get the doc id dictionary

                if inp[1] in doc_dict:  # check if value in doc id dictionary
                    doc_dict[inp[1]] += 1   # update the term frequency

                else:
                    doc_dict.update({inp[1]: 1})  # update the doc id dictionary
            else:
                temp_list[inp[0]] = {inp[1]: 1}

        else:
            block_list.append(dict(sorted(temp_list.items())))  # append the block list with block
            # print(block_list)

            temp_list = {}  # re- initialise the temporary list
            count = 0   # re-initialise the count to 0

    # print(len(block_list))
    f_block = block_list[0]
    l_block = block_list[-1]

    # json.dump(f_block, open("firstblock.json", "w", encoding="utf−8"))
    # json.dump(l_block, open("lastblock.json", "w", encoding="utf−8"))



def merge_block(INPUT_STRUCTURE):   # merging all the terms from all the blocks

    while len(INPUT_STRUCTURE) != 0:    # while the block list is not empty

        s_term = list(INPUT_STRUCTURE[0].keys())[0] # select the first element of first block as the smallest token

        # print(s_term)
        # print(INPUT_STRUCTURE[0][s_term])

        for block in INPUT_STRUCTURE:
            if list(block.keys())[0] < s_term:  # check if the first element of another block is smaller than s_term
                s_term = list(block.keys())[0]

        for block in INPUT_STRUCTURE:   # iterate the blocks in block_list

            if s_term in block:   # check if s_term is present in the block or not

                if s_term not in merge_dict:
                    merge_dict[s_term] = block[s_term]  # if s_term  ot in merge dict then create entry

                else:
                    doc_dict = merge_dict[s_term]   # get the value of doc dictionary in merge list

                    for d_id in block[s_term]:  # iterate the doc id's in document dictionary of block

                        # print(d_id)

                        if d_id in list(doc_dict.keys()):   # check if doc id is present in merge list
                            doc_dict[d_id] += block[s_term][d_id]   # update term frequency in merge list

                        else:
                            merge_dict[s_term].update({d_id: block[s_term][d_id]})  # update the dictionary with doc id

                del block[s_term]   # delete the the term from the block

            if len(block) == 0: # check if the block is empty
                INPUT_STRUCTURE.remove(block) # delete the block from list


    #print(s_term)
    #print(merge_dict)









