import json
import time

import SP1
import SP2

start = time.time()
SP1.reader("./reuters21578") # reading the reuters
SP1.document_segmenter(SP1.reuters_doc) #segment the document
SP1.extractor(SP1.doc_text) # extract to the doccument
SP1.tokenizer(SP1.content_dict) # tokenise the text
SP1.block_generate(SP1.token_tuple) # generate the blocks of size 500
print("Total time taken by to build is--- %s seconds ---" % (time.time() - start))
SP1.merge_block(SP1.block_list) # generate the merged index

# Test 1 single word query
p1 = SP2.bm25('CHICAGO', 5, 0.5)
p2 = SP2.bm25('Alcan', 2, 0.5)
p3 = SP2.bm25('CHICAGO', 3, 0.6)
p4 = SP2.bm25('Alcan', 4, 0.4)
json.dump(p1, open("test_query1_1.json", "w", encoding="utf−8"))
json.dump(p2, open("test_query1_2.json", "w", encoding="utf−8"))
json.dump(p3, open("test_query1_3.json", "w", encoding="utf−8"))
json.dump(p4, open("test_query1_4.json", "w", encoding="utf−8"))

# Test 2 several keywords query for bm25
p1 = SP2.bm25_s('The management market')
json.dump(p1, open("test_query2.json", "w", encoding="utf−8"))

# Test 3 multiple keyword query for AND
p1 = SP2.SPIMI_AND('earth minerals titanium')
json.dump(p1, open("test_query3.json", "w", encoding="utf−8"))

# Test 4 multiple keyword query for OR
p1 = SP2.SPIMI_OR('additional preference proposed')
json.dump(p1, open("test_query4.json", "w", encoding="utf−8"))

# Sample run 1 - Democrats’ welfare and healthcare reform policies
p1 = SP2.bm25_s('Democrats welfare and healthcare reform policies')
json.dump(p1, open("sample_run_1.json", "w", encoding="utf−8"))

# Sample run 2 - Drug company bankruptcies
p1 = SP2.bm25_s('Drug company bankruptcies')
json.dump(p1, open("sample_run_2.json", "w", encoding="utf−8"))

# Sample run 3 - George Bush
p1 = SP2.bm25_s('George Bush')
json.dump(p1, open("sample_run_3.json", "w", encoding="utf−8"))

