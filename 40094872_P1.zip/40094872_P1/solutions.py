"""
Write your reusable code here.
Main method stubs corresponding to each block is initialized here. Do not modify the signature of the functions already
created for you. But if necessary you can implement any number of additional functions that you might think useful to you
within this script.

Delete "Delete this block first" code stub after writing solutions to each function.

Write you code within the "WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv" code stub. Variable created within this stub are just
for example to show what is expected to be returned. You CAN modify them according to your preference.
"""
import os
import nltk
from nltk.corpus import stopwords
from bs4 import BeautifulSoup
from nltk import word_tokenize, PorterStemmer
import regex
document = [] # empty list for appending split documents


def block_reader(path):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_reader function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^
    for file in os.listdir(path):
        if file.endswith('.sgm'):   # checking for files with .sgm extension
            with open(os.path.join(path, file), # open the files and ignore errors to avoid utf-8 error
                      errors='ignore') as f:
                reuters_file_content = f.read() # putting all the read text in reuters_file_content
                yield reuters_file_content
                break # breaking the loop after first iteration to obtain only one .sgm file


def block_document_segmenter(INPUT_STRUCTURE):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_document_segmenter function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv

    for inp in INPUT_STRUCTURE:
        # using the regex to append the empty document list
        document.append(regex.split('<!DOCTYPE lewis SYSTEM "lewis.dtd">', inp)[1])

    doc_count = 0   # introducing a variable to check for only 5 newspaper documents
    for doc in document:
        inp = doc
        flag = True     # using a flag to check for document end

        while flag:     # loop while the flag is true
            start_tag = inp.index('<REUTERS')   # tags to define the start index of a reuter
            end_tag = inp.index('</REUTERS>')   # tags to define the end index of a reuter
            if doc_count == 5:  # check if 5 documents have been received
                break
            if '<REUTERS' in inp:
                document_text = inp[start_tag: end_tag + 10]    # populate document_text with reuters content
                inp = inp[end_tag + 10:]    # update the index value
                yield document_text
                doc_count = doc_count + 1   # update loop count
            else:
                flag = False


def block_extractor(INPUT_STRUCTURE):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_extractor function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^

    for inp in INPUT_STRUCTURE:
        bs = BeautifulSoup(inp, 'html.parser')  # using beautiful soup to parse html/xml
        text = bs.find('text')
        # print(text.get('type'))

        if text.get('type') == 'UNPROC' or text.get('type') == 'BRIEF': # check for text type unproc and brief
            error = "empty blocks"
        else:
            reuters = bs.find('reuters')    # find reuters
            iD = int(reuters.get('newid'))  # find the docID
            title = bs.find('title').string # find the title
            dateline = bs.find('dateline').string   # find the dateline
            body = bs.find('body').string   # find the body
            finalText = title + dateline + body # concatenate the final string
            content_dict = {"ID": iD, "TEXT": finalText}  # dictionary structure of output
            yield content_dict


def block_tokenizer(INPUT_STRUCTURE):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_tokenizer function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^

    for inp in INPUT_STRUCTURE:
        text = word_tokenize(inp['TEXT'])   # using word tokenizer to generate tokens

        for t in text:
            token_tuple = (inp['ID'], t)  # token tuple structure of output
            yield token_tuple


def block_stemmer(INPUT_STRUCTURE):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_stemmer function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv
    # token_tuple = ('id', 'token')  # Sample id, token tuple structure of output
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^

    # using a special symbol list to remove unwanted tokens
    special_symbols = '''!()-[]{};:'"\,<>./``''?@#$%^&*_~'''
    for inp in INPUT_STRUCTURE:

        if inp[1] not in special_symbols:
            token_tuple = (inp[0], PorterStemmer().stem(inp[1]))    # generating tokens after stemming the output of block 4
            yield token_tuple


def block_stopwords_removal(INPUT_STRUCTURE, stopwords):
    # Delete this block first
    # raise NotImplementedError("Please implement your solution in block_stopwords_removal function in solutions.py")
    # ##############
    # WRITE YOUR CODE HERE vvvvvvvvvvvvvvvv
    # WRITE YOUR CODE HERE ^^^^^^^^^^^^^^^^
    stopword = list(nltk.corpus.stopwords.words('english')) # generating a list of stop words in english language
    for inp in INPUT_STRUCTURE:
        if inp[1] in stopword:  # check if stop word is present in token
            error = "stop word found"
        else:
            token_tuple = (inp[0], inp[1])  # generate a dictionary without stop words
            yield token_tuple
